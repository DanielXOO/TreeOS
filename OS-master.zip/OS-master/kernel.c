#include "I_Olib.h"
void kmain(void)
{
    const char *str = "its better than windows ";
    proper();
    out(str);   
    return;
}

    



